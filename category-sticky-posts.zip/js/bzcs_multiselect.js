jQuery(document).ready(function($){
  $(".bz-category-sticky-multiselect").multiselect({sortable: false, searchable: true});
});